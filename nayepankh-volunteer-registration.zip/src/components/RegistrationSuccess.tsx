import React from "react";
import { Sparkles, CheckCircle2, ArrowLeft, Heart, Calendar, BookmarkCheck } from "lucide-react";
import { Volunteer } from "../types";

interface RegistrationSuccessProps {
  volunteer: Volunteer;
  onReset: () => void;
  onViewDashboard: () => void;
}

export default function RegistrationSuccess({
  volunteer,
  onReset,
  onViewDashboard
}: RegistrationSuccessProps) {
  return (
    <div id="registration-success-card" className="w-full max-w-2xl mx-auto block bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl p-6 sm:p-10 shadow-lg text-center animate-fade-in">
      
      {/* Animated Success Badge */}
      <div className="flex justify-center mb-6">
        <div className="relative">
          <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl animate-pulse" />
          <div className="relative p-5 bg-emerald-50 dark:bg-emerald-950/40 rounded-full border border-emerald-100 dark:border-emerald-900/60 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-14 h-14" />
          </div>
        </div>
      </div>

      <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-zinc-900 dark:text-white leading-tight mb-3">
        You're Officially Registered!
      </h2>
      
      <p className="text-zinc-500 dark:text-zinc-400 max-w-md mx-auto text-sm leading-relaxed mb-8">
        Welcome to the NayePankh Foundation Family, <span className="font-bold text-emerald-600 dark:text-emerald-400">{volunteer.name}</span>! Your request has been securely persisted in our National REST database. Our city coordinator will reach out to you via SMS/Email soon.
      </p>

      {/* Structured Details Summary Card */}
      <div className="bg-zinc-50 dark:bg-zinc-950 rounded-2xl p-5 border border-zinc-100 dark:border-zinc-900 text-left mb-8 max-w-md mx-auto space-y-3.5">
        <h3 className="text-xs font-bold text-zinc-400 dark:text-zinc-500 tracking-wider uppercase flex items-center justify-between border-b border-zinc-100 dark:border-zinc-900 pb-2">
          <span>Volunteer Profile Summary</span>
          <span className="font-mono bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 px-2.5 py-0.5 rounded-full text-[10px]">
            {volunteer.id}
          </span>
        </h3>

        <div className="grid grid-cols-3 text-xs">
          <span className="text-zinc-400 font-medium">Full Name:</span>
          <span className="col-span-2 text-zinc-900 dark:text-zinc-100 font-semibold">{volunteer.name}</span>
        </div>

        <div className="grid grid-cols-3 text-xs">
          <span className="text-zinc-400 font-medium">Email:</span>
          <span className="col-span-2 text-zinc-900 dark:text-zinc-100 font-medium break-all">{volunteer.email}</span>
        </div>

        <div className="grid grid-cols-3 text-xs">
          <span className="text-zinc-400 font-medium">City:</span>
          <span className="col-span-2 text-zinc-900 dark:text-zinc-100 font-semibold">{volunteer.city}</span>
        </div>

        <div className="grid grid-cols-3 text-xs">
          <span className="text-zinc-400 font-medium">Availability:</span>
          <span className="col-span-2 text-zinc-900 dark:text-zinc-100 font-semibold text-emerald-600 dark:text-emerald-400">{volunteer.availability}</span>
        </div>

        <div className="grid grid-cols-3 text-xs">
          <span className="text-zinc-400 font-medium">Skills Added:</span>
          <span className="col-span-2 text-zinc-900 dark:text-zinc-100 line-clamp-2 italic">{volunteer.skills}</span>
        </div>
      </div>

      {/* Call to Actions */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
        <button
          id="btn-success-reset"
          onClick={onReset}
          className="w-full sm:w-auto flex items-center justify-center space-x-1.5 px-6 py-3.5 rounded-xl bg-transparent hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 font-semibold border border-zinc-200 dark:border-zinc-800 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Register Another</span>
        </button>

        <button
          id="btn-success-view-dashboard"
          onClick={onViewDashboard}
          className="w-full sm:w-auto flex items-center justify-center space-x-1.5 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-xs transition"
        >
          <BookmarkCheck className="w-5 h-5" />
          <span>View Dashboard</span>
        </button>
      </div>

      <div className="mt-8 flex items-center justify-center space-x-2 text-xs text-rose-500 font-semibold">
        <Heart className="w-4 h-4 fill-current text-rose-500 animate-bounce" />
        <span>Thank you for making a difference!</span>
      </div>

    </div>
  );
}
