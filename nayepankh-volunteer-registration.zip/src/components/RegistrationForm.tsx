import React, { useState } from "react";
import { User, Mail, Phone, MapPin, Calendar, Heart, Sliders, ArrowRight } from "lucide-react";

interface RegistrationFormProps {
  onSubmitSuccess: (newVolunteer: any) => void;
}

export default function RegistrationForm({ onSubmitSuccess }: RegistrationFormProps) {
  // Form values state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [age, setAge] = useState("");
  const [skills, setSkills] = useState("");
  const [availability, setAvailability] = useState("Weekends");

  // Errors state
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  // Common options for quick select/input helper
  const popularCities = ["Delhi", "Mumbai", "Bangalore", "Kolkata", "Chennai", "Hyderabad", "Pune", "Noida", "Lucknow", "Ahmedabad"];
  const commonSkills = [
    "Teaching / Academic Tutoring",
    "Social Media & Content Writing",
    "Event Planning & Management",
    "Fundraising & Campaigns",
    "Graphic Design & Photography",
    "Health & Hygiene Support",
    "Environmental Conservation"
  ];

  const validateForm = () => {
    const tempErrors: Record<string, string> = {};

    if (!name.trim()) {
      tempErrors.name = "Full Name is required.";
    } else if (name.trim().length < 3) {
      tempErrors.name = "Name must be at least 3 characters long.";
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) {
      tempErrors.email = "Email Address is required.";
    } else if (!emailRegex.test(email)) {
      tempErrors.email = "Please specify a valid email address.";
    }

    // Indian phone numbers are usually 10 digits
    const cleanPhone = phone.replace(/[^0-9+]/g, "");
    if (!phone.trim()) {
      tempErrors.phone = "Phone Number is required.";
    } else if (cleanPhone.length < 10) {
      tempErrors.phone = "Phone number should be at least 10 digits.";
    }

    if (!city.trim()) {
      tempErrors.city = "City is required.";
    }

    const ageNum = parseInt(age);
    if (!age) {
      tempErrors.age = "Please enter your age.";
    } else if (isNaN(ageNum)) {
      tempErrors.age = "Age must be a valid number.";
    } else if (ageNum < 14 || ageNum > 90) {
      tempErrors.age = "Volunteers must be between 14 and 90 years old.";
    }

    if (!skills.trim()) {
      tempErrors.skills = "Please list your skills or interests.";
    } else if (skills.trim().length < 5) {
      tempErrors.skills = "Tell us a bit more about your skills (at least 5 characters).";
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    try {
      const response = await fetch("/api/volunteers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          email,
          phone,
          city,
          age: parseInt(age),
          skills,
          availability,
        }),
      });

      if (response.ok) {
        const newVolunteer = await response.json();
        onSubmitSuccess(newVolunteer);
        // Clear state
        setName("");
        setEmail("");
        setPhone("");
        setCity("");
        setAge("");
        setSkills("");
        setAvailability("Weekends");
        setErrors({});
      } else {
        const errorData = await response.json();
        setErrors({ form: errorData.error || "An error occurred. Please try again." });
      }
    } catch (err) {
      console.error(err);
      setErrors({ form: "Could not connect to the backend server. Please verify connections." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="registration-form-card" className="w-full max-w-2xl mx-auto block bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl p-6 sm:p-10 shadow-xs">
      
      {/* Title */}
      <div className="text-center mb-8">
        <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-zinc-900 dark:text-white">
          Join the Movement
        </h2>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-2 max-w-sm mx-auto">
          Complete this short registration form to become a volunteer. Together, we can build wings of change!
        </p>
      </div>

      {errors.form && (
        <div id="form-general-error" className="mb-6 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 text-sm font-semibold border border-rose-100 dark:border-rose-900/40">
          {errors.form}
        </div>
      )}

      <form id="volunteer-reg-form" onSubmit={handleSubmit} className="space-y-6">
        
        {/* Full Name */}
        <div>
          <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
            Full Name
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400 dark:text-zinc-500">
              <User className="w-5 h-5" />
            </div>
            <input
              id="input-full-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rahul Sharma"
              className={`w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border ${
                errors.name 
                  ? "border-rose-400 focus:ring-rose-500" 
                  : "border-zinc-200 dark:border-zinc-800 focus:ring-emerald-500"
              } focus:outline-hidden focus:ring-2 dark:text-white transition-all`}
            />
          </div>
          {errors.name && <p id="error-full-name" className="text-rose-600 dark:text-rose-400 text-xs font-semibold mt-1.5 ml-1">{errors.name}</p>}
        </div>

        {/* Two-column layout: Email and Phone */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Email Address */}
          <div>
            <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
              Email Address
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400 dark:text-zinc-500">
                <Mail className="w-5 h-5" />
              </div>
              <input
                id="input-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="rahul@example.com"
                className={`w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border ${
                  errors.email 
                    ? "border-rose-400 focus:ring-rose-500" 
                    : "border-zinc-200 dark:border-zinc-800 focus:ring-emerald-500"
                } focus:outline-hidden focus:ring-2 dark:text-white transition-all`}
              />
            </div>
            {errors.email && <p id="error-email" className="text-rose-600 dark:text-rose-400 text-xs font-semibold mt-1.5 ml-1">{errors.email}</p>}
          </div>

          {/* Phone Number */}
          <div>
            <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
              Phone Number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400 dark:text-zinc-500">
                <Phone className="w-5 h-5" />
              </div>
              <input
                id="input-phone"
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. +91 98765 43210"
                className={`w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border ${
                  errors.phone 
                    ? "border-rose-400 focus:ring-rose-500" 
                    : "border-zinc-200 dark:border-zinc-800 focus:ring-emerald-500"
                } focus:outline-hidden focus:ring-2 dark:text-white transition-all`}
              />
            </div>
            {errors.phone && <p id="error-phone" className="text-rose-600 dark:text-rose-400 text-xs font-semibold mt-1.5 ml-1">{errors.phone}</p>}
          </div>
        </div>

        {/* Two-column layout: City and Age */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* City */}
          <div>
            <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
              City / Location
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400 dark:text-zinc-500">
                <MapPin className="w-5 h-5" />
              </div>
              <input
                id="input-city"
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. Noida, Delhi"
                className={`w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border ${
                  errors.city 
                    ? "border-rose-400 focus:ring-rose-500" 
                    : "border-zinc-200 dark:border-zinc-800 focus:ring-emerald-500"
                } focus:outline-hidden focus:ring-2 dark:text-white transition-all`}
                list="popular-cities-list"
              />
              <datalist id="popular-cities-list">
                {popularCities.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>
            {errors.city && <p id="error-city" className="text-rose-600 dark:text-rose-400 text-xs font-semibold mt-1.5 ml-1">{errors.city}</p>}
          </div>

          {/* Age */}
          <div>
            <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
              Age
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400 dark:text-zinc-500">
                <Calendar className="w-5 h-5" />
              </div>
              <input
                id="input-age"
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="e.g. 21"
                min="1"
                className={`w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border ${
                  errors.age 
                    ? "border-rose-400 focus:ring-rose-500" 
                    : "border-zinc-200 dark:border-zinc-800 focus:ring-emerald-500"
                } focus:outline-hidden focus:ring-2 dark:text-white transition-all`}
              />
            </div>
            {errors.age && <p id="error-age" className="text-rose-600 dark:text-rose-400 text-xs font-semibold mt-1.5 ml-1">{errors.age}</p>}
          </div>
        </div>

        {/* Skills and Interests */}
        <div>
          <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
            Skills & Interests
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 pt-3.5 pointer-events-none text-zinc-400 dark:text-zinc-500">
              <Heart className="w-5 h-5" />
            </div>
            <textarea
              id="input-skills"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              placeholder="Tell us what you are good at (e.g. Teaching Children, Graphic Design, Arranging Food Drives)"
              rows={3}
              className={`w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border ${
                errors.skills 
                  ? "border-rose-400 focus:ring-rose-500" 
                  : "border-zinc-200 dark:border-zinc-800 focus:ring-emerald-500"
              } focus:outline-hidden focus:ring-2 dark:text-white transition-all`}
            />
          </div>
          {errors.skills && <p id="error-skills" className="text-rose-600 dark:text-rose-400 text-xs font-semibold mt-1.5 ml-1">{errors.skills}</p>}
          
          {/* Quick Select Buttons */}
          <div className="mt-3">
            <span className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">Click to insert standard interests: </span>
            <div className="flex flex-wrap gap-2 mt-1.5">
              {commonSkills.map((skill) => (
                <button
                  key={skill}
                  type="button"
                  onClick={() => {
                    const current = skills.trim();
                    if (!current) {
                      setSkills(skill);
                    } else if (!current.includes(skill)) {
                      setSkills(current + ", " + skill);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded-full bg-zinc-100 hover:bg-emerald-50 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 hover:text-emerald-700 transition"
                >
                  + {skill.split(" / ")[0]}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Availability */}
        <div>
          <label className="block text-sm font-bold text-zinc-700 dark:text-zinc-300 mb-2">
            Your Availability
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-400 dark:text-zinc-500">
              <Sliders className="w-5 h-5" />
            </div>
            <select
              id="input-availability"
              value={availability}
              onChange={(e) => setAvailability(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-zinc-50 dark:bg-zinc-950/40 rounded-2xl border border-zinc-200 dark:border-zinc-800 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden dark:text-white transition-all appearance-none"
            >
              <option value="Weekends">Weekends Only</option>
              <option value="Weekdays (Evenings)">Weekdays (Evenings)</option>
              <option value="Flexible">Fully Flexible / On-Call</option>
              <option value="Full-time">Full-time Support (Internships/Campaigns)</option>
            </select>
          </div>
        </div>

        {/* Submit */}
        <button
          id="btn-submit-registration"
          type="submit"
          disabled={loading}
          className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold shadow-md hover:shadow-lg transition-transform focus:ring-4 focus:ring-emerald-300 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 select-none flex items-center justify-center space-x-2 text-base"
        >
          <span>{loading ? "Registering Dreamer..." : "Submit Volunteer Request"}</span>
          <ArrowRight className="w-5 h-5" />
        </button>

      </form>
    </div>
  );
}
