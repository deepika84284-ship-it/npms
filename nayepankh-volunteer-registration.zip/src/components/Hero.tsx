import React from "react";
import { Users, Heart, Sparkles, Smile, ShieldCheck, ArrowRight, BookOpen, HandHelping } from "lucide-react";

interface HeroProps {
  onRegisterClick: () => void;
  volunteerCount: number;
}

export default function Hero({ onRegisterClick, volunteerCount }: HeroProps) {
  const impacts = [
    {
      icon: BookOpen,
      title: "Quality Education",
      description: "Empowering young under-privileged children with basic reading, writing, and practical life skills.",
      bgColor: "bg-emerald-50 dark:bg-emerald-950/40",
      textColor: "text-emerald-600 dark:text-emerald-400"
    },
    {
      icon: HandHelping,
      title: "Food Distribution",
      description: "Arranging and delivering meals to families, homeless individuals, and kids in need.",
      bgColor: "bg-amber-50 dark:bg-amber-950/40",
      textColor: "text-amber-600 dark:text-amber-400"
    },
    {
      icon: Smile,
      title: "Young Minds Uplift",
      description: "Nurturing creative skills, self-confidence, and self-reliance in tier-2 & tier-3 rural youth.",
      bgColor: "bg-blue-50 dark:bg-blue-950/40",
      textColor: "text-blue-600 dark:text-blue-400"
    }
  ];

  return (
    <div id="hero-section" className="relative overflow-hidden pt-12 pb-20 lg:pt-16 lg:pb-28">
      {/* Background blobs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-emerald-300/10 dark:bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -right-20 w-96 h-96 bg-amber-400/5 dark:bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Banner Announcement */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-100 dark:border-emerald-900/60 shadow-xs">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400 animate-spin" />
            <span className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
              National Non-Governmental Organization (NGO) Status
            </span>
          </div>
        </div>

        {/* Hero Copy */}
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-zinc-900 dark:text-white tracking-tight leading-[1.12] mb-6">
            Give Wings to Dreams with <br/>
            <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
              NayePankh Foundation
            </span>
          </h1>

          <p className="text-lg md:text-xl text-zinc-600 dark:text-zinc-400 font-normal leading-relaxed max-w-3xl mx-auto mb-10">
            NayePankh Foundation is one of India's leading youth-driven groups working towards lifting up underprivileged lives. We provide resources, essential coaching, food drives, and build local networks to create sustainable change.
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <button
              id="cta-become-volunteer-hero"
              onClick={onRegisterClick}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center space-x-2 text-base select-none"
            >
              <span>Become a Volunteer</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            
            <a
              href="https://nayepankh.org"
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-transparent hover:bg-zinc-100 dark:hover:bg-zinc-900 text-zinc-800 dark:text-zinc-200 font-semibold border border-zinc-200 dark:border-zinc-800 transition-all duration-300 flex items-center justify-center space-x-2 text-base"
            >
              <span>Explore Website</span>
            </a>
          </div>
        </div>

        {/* Live Counters */}
        <div id="stats-grid" className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-20">
          <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 shadow-xs text-center hover:scale-102 transition-transform duration-300">
            <div className="inline-flex p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl mb-3">
              <Users className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white">
              {Math.max(105, volunteerCount + 105)}+
            </div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium tracking-wide uppercase mt-1">
              Active Volunteers
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 shadow-xs text-center hover:scale-102 transition-transform duration-300">
            <div className="inline-flex p-3 bg-rose-50 dark:bg-rose-950/40 rounded-2xl mb-3">
              <Heart className="w-6 h-6 text-rose-500 dark:text-rose-400" />
            </div>
            <div className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white">
              15,000+
            </div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium tracking-wide uppercase mt-1">
              Lives Positively Impacted
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 shadow-xs text-center hover:scale-102 transition-transform duration-300">
            <div className="inline-flex p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl mb-3">
              <ShieldCheck className="w-6 h-6 text-amber-500 dark:text-amber-400" />
            </div>
            <div className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white">
              20+
            </div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium tracking-wide uppercase mt-1">
              Cities Covered
            </div>
          </div>
        </div>

        {/* Callouts/Pillars of Impact section */}
        <div className="mt-8 border-t border-zinc-100 dark:border-zinc-900 pt-16">
          <div className="text-center mb-12">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-zinc-900 dark:text-white">
              Where Your Help Matters Most
            </h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-2 max-w-xl mx-auto">
              Our volunteers work on real-world projects directly inside diverse Indian communities, delivering educational resources, clean hygiene, and relief.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {impacts.map((impact, idx) => {
              const ImpactIcon = impact.icon;
              return (
                <div
                  key={idx}
                  className="p-8 rounded-3xl bg-white dark:bg-zinc-900/60 border border-zinc-100 dark:border-zinc-800/80 shadow-xs transition-all duration-300 hover:shadow-md flex flex-col items-start"
                >
                  <div className={`p-3.5 rounded-2xl mb-5 ${impact.bgColor}`}>
                    <ImpactIcon className={`w-6 h-6 ${impact.textColor}`} />
                  </div>
                  <h3 className="font-display text-lg font-bold text-zinc-900 dark:text-white mb-2.5">
                    {impact.title}
                  </h3>
                  <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed font-normal">
                    {impact.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
