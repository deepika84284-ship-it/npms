import React, { useState } from "react";
import { Feather, Menu, X, ShieldAlert, Award, LogOut } from "lucide-react";
import ThemeToggle from "./ThemeToggle";

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  isAdmin: boolean;
  onLogout: () => void;
}

export default function Navbar({
  currentTab,
  setCurrentTab,
  darkMode,
  setDarkMode,
  isAdmin,
  onLogout
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  const navItems = [
    { id: "home", label: "Home" },
    { id: "register", label: "Register" },
    { id: "dashboard", label: "Admin Panel", icon: ShieldAlert }
  ];

  const handleTabClick = (tabId: string) => {
    setCurrentTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <nav id="app-navbar" className="sticky top-0 z-50 backdrop-blur-md bg-white/80 dark:bg-zinc-950/80 border-b border-rose-100/50 dark:border-zinc-800/80 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Brand */}
          <div 
            id="brand-logo-container" 
            onClick={() => handleTabClick("home")}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/50 rounded-2xl border border-emerald-100 dark:border-emerald-800/60 shadow-xs group-hover:rotate-12 transition-transform duration-300">
              <Feather className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <span className="block font-display text-xl font-extrabold tracking-tight text-zinc-900 dark:text-white leading-tight">
                NayePankh
              </span>
              <span className="block text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 tracking-widest uppercase">
                Foundation
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  id={`nav-link-${item.id}`}
                  key={item.id}
                  onClick={() => handleTabClick(item.id)}
                  className={`flex items-center space-x-1 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 select-none ${
                    isActive
                      ? "bg-emerald-600 text-white shadow-xs"
                      : "text-zinc-600 hover:bg-emerald-50 hover:text-emerald-700 dark:text-zinc-300 dark:hover:bg-zinc-900/60 dark:hover:text-emerald-400"
                  }`}
                >
                  {Icon && <Icon className="w-4 h-4 mr-0.5" />}
                  <span>{item.label}</span>
                </button>
              );
            })}

            {isAdmin && (
              <button
                id="btn-nav-logout"
                onClick={onLogout}
                title="Log Out Admin"
                className="flex items-center space-x-1.5 px-3 py-2 rounded-xl text-sm font-semibold text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/30 transition-all duration-300 select-none border border-rose-100 dark:border-rose-950/60"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden lg:inline">Sign Out</span>
              </button>
            )}
          </div>

          {/* Right utility buttons: Theme toggle and mobile menu */}
          <div className="flex items-center space-x-4">
            <ThemeToggle darkMode={darkMode} onToggle={toggleDarkMode} />

            <div className="md:hidden">
              <button
                id="mobile-menu-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2.5 rounded-xl text-zinc-600 dark:text-zinc-300 hover:bg-emerald-50 dark:hover:bg-zinc-900 border border-transparent dark:border-zinc-800 transition-colors"
                aria-label="Toggle mobile menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      {mobileMenuOpen && (
        <div id="mobile-nav-panel" className="md:hidden animate-fade-in border-t border-zinc-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 px-4 pt-2 pb-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                id={`mobile-nav-link-${item.id}`}
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left text-sm font-semibold transition-all duration-200 ${
                  isActive
                    ? "bg-emerald-600 text-white"
                    : "text-zinc-700 dark:text-zinc-300 hover:bg-emerald-50 dark:hover:bg-zinc-900"
                }`}
              >
                {Icon && <Icon className="w-5 h-5 text-emerald-500" />}
                <span>{item.label}</span>
              </button>
            );
          })}

          {isAdmin && (
            <button
              id="mobile-btn-logout"
              onClick={() => {
                onLogout();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left text-sm font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all duration-200 border border-rose-100 dark:border-rose-900/30"
            >
              <LogOut className="w-5 h-5" />
              <span>Sign Out Admin</span>
            </button>
          )}

          <div className="pt-2 border-t border-zinc-100 dark:border-zinc-900 mt-2">
            <div className="flex items-center justify-between px-4 py-2">
              <span className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">NayePankh Foundation Support</span>
              <Award className="w-4 h-4 text-emerald-500" />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
