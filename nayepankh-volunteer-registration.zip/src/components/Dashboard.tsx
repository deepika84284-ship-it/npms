import React, { useState } from "react";
import { Search, MapPin, Trash2, SlidersHorizontal, Award, Sparkles, Smile, RefreshCw, Layers, Calendar, UserCheck } from "lucide-react";
import { Volunteer } from "../types";

interface DashboardProps {
  volunteers: Volunteer[];
  onDeleteVolunteer: (id: string) => void;
  onRefresh: () => void;
  isLoading: boolean;
}

export default function Dashboard({
  volunteers,
  onDeleteVolunteer,
  onRefresh,
  isLoading
}: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCity, setSelectedCity] = useState("All");
  const [selectedSkill, setSelectedSkill] = useState("All");

  // Get unique lists for filtering
  const cities = ["All", ...Array.from(new Set(volunteers.map((v) => v.city).filter(Boolean)))];
  
  // Custom smart list of core skills/categories based on common interests
  const skillCategories = [
    "All",
    "Teaching",
    "Social Media",
    "Event Management",
    "Fundraising",
    "Graphic Design",
    "Writing",
    "Environmental"
  ];

  // Apply filters
  const filteredVolunteers = volunteers.filter((vol) => {
    const matchesSearch = vol.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          vol.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          vol.phone.includes(searchTerm);
    
    const matchesCity = selectedCity === "All" || vol.city.toLowerCase() === selectedCity.toLowerCase();
    
    const matchesSkill = selectedSkill === "All" || 
      vol.skills.toLowerCase().includes(selectedSkill.toLowerCase());

    return matchesSearch && matchesCity && matchesSkill;
  });

  // Calculate simple analytics for visual appeal
  const totalCount = volunteers.length;
  const avgAge = totalCount > 0 
    ? Math.round(volunteers.reduce((sum, v) => sum + (v.age || 0), 0) / totalCount)
    : 0;
  
  // Format dates nicely
  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric"
      });
    } catch {
      return "Pending";
    }
  };

  const handleExportData = () => {
    if (filteredVolunteers.length === 0) return;
    const headers = ["ID", "Name", "Email", "Phone", "City", "Age", "Skills", "Availability", "Registered At"];
    const rows = filteredVolunteers.map(v => [
      v.id,
      v.name,
      v.email,
      v.phone,
      v.city,
      v.age,
      `"${v.skills.replace(/"/g, '""')}"`,
      v.availability,
      v.createdAt
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "nayepankh_volunteers_export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="dashboard-container" className="space-y-8 animate-fade-in text-zinc-900 dark:text-zinc-100">
      
      {/* Header and Statistics Overview */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="font-display text-3xl font-extrabold tracking-tight text-zinc-900 dark:text-white flex items-center gap-2">
            <UserCheck className="w-8 h-8 text-emerald-600 dark:text-emerald-400" />
            <span>Volunteer Directory & Registry</span>
          </h2>
          <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            Browse, search and administer active volunteer enrollments for the current recruitment drive.
          </p>
        </div>

        {/* Floating controls */}
        <div className="flex items-center space-x-3 w-full md:w-auto">
          <button
            id="btn-refresh-dashboard"
            onClick={onRefresh}
            disabled={isLoading}
            className="flex items-center space-x-1.5 px-4 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 text-sm font-semibold transition"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
            <span>{isLoading ? "Refreshing..." : "Refresh Database"}</span>
          </button>

          <button
            id="btn-export-csv"
            onClick={handleExportData}
            disabled={filteredVolunteers.length === 0}
            className="flex-1 md:flex-initial px-5 py-2.5 rounded-xl bg-zinc-900 dark:bg-zinc-100 hover:bg-zinc-800 dark:hover:bg-zinc-200 text-white dark:text-zinc-900 text-sm font-bold shadow-xs transition disabled:opacity-40"
          >
            Export CSV ({filteredVolunteers.length})
          </button>
        </div>
      </div>

      {/* Analytics Mini-Bentos */}
      <div id="analytics-mini-widgets" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total registered */}
        <div className="p-5 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl shadow-xs">
          <p className="text-xs text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider">Total Volunteers</p>
          <div className="flex items-end space-x-2 mt-2">
            <span className="font-display text-2xl font-extrabold">{totalCount}</span>
            <span className="text-xs text-emerald-600 dark:text-emerald-450 font-bold mb-1">+Live Sync</span>
          </div>
        </div>

        {/* Average Age */}
        <div className="p-5 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl shadow-xs">
          <p className="text-xs text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider">Average Volunteer Age</p>
          <div className="flex items-end space-x-2 mt-2">
            <span className="font-display text-2xl font-extrabold">{avgAge || "--"}</span>
            <span className="text-xs text-zinc-400 font-semibold mb-1">years old</span>
          </div>
        </div>

        {/* Unique Cities */}
        <div className="p-5 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl shadow-xs">
          <p className="text-xs text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider">Active Chapters (Cities)</p>
          <div className="flex items-end space-x-2 mt-2">
            <span className="font-display text-2xl font-extrabold">{cities.length - 1}</span>
            <span className="text-xs text-zinc-400 font-semibold mb-1">regional zones</span>
          </div>
        </div>

        {/* High Need matching callout */}
        <div className="p-5 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-950 rounded-3xl shadow-xs flex items-center justify-between">
          <div>
            <span className="block text-[10px] text-emerald-700 dark:text-emerald-400 font-bold uppercase tracking-widest">DRIVE PRIORITY</span>
            <span className="block font-display text-sm font-bold text-emerald-900 dark:text-emerald-200 mt-1">Teaching & Feeds</span>
            <p className="text-[10px] text-emerald-600 dark:text-emerald-500 font-medium mt-0.5">High need categories</p>
          </div>
          <Sparkles className="w-8 h-8 text-emerald-500/80 animate-pulse" />
        </div>

      </div>

      {/* Filter panel */}
      <div id="filter-controls-panel" className="bg-zinc-50 dark:bg-zinc-900/60 border border-zinc-100 dark:border-zinc-800 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
        
        <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-3">
          <div className="flex items-center space-x-2">
            <SlidersHorizontal className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-zinc-700 dark:text-zinc-300">Filter and Search Engine</h3>
          </div>
          {(searchTerm || selectedCity !== "All" || selectedSkill !== "All") && (
            <button
              onClick={() => {
                setSearchTerm("");
                setSelectedCity("All");
                setSelectedSkill("All");
              }}
              className="text-xs text-emerald-600 hover:text-emerald-700 font-bold select-none cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Search Term Input */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              id="search-filter-name"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name, email, phone..."
              className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 dark:text-white text-xs"
            />
          </div>

          {/* City Selection */}
          <div className="relative flex items-center bg-white dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 focus-within:ring-2 focus-within:ring-emerald-500">
            <div className="pl-3 text-zinc-400 pointer-events-none">
              <MapPin className="w-4 h-4" />
            </div>
            <select
              id="select-filter-city"
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full pl-2 pr-4 py-2.5 bg-transparent rounded-xl focus:outline-hidden dark:text-white select-none text-xs appearance-none cursor-pointer"
            >
              {cities.map((city) => (
                <option key={city} value={city}>
                  {city === "All" ? "Filter by City: All" : city}
                </option>
              ))}
            </select>
          </div>

          {/* Skill Selection */}
          <div className="relative flex items-center bg-white dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 focus-within:ring-2 focus-within:ring-emerald-500">
            <div className="pl-3 text-zinc-400 pointer-events-none">
              <Layers className="w-4 h-4" />
            </div>
            <select
              id="select-filter-skill"
              value={selectedSkill}
              onChange={(e) => setSelectedSkill(e.target.value)}
              className="w-full pl-2 pr-4 py-2.5 bg-transparent rounded-xl focus:outline-hidden dark:text-white select-none text-xs appearance-none cursor-pointer"
            >
              {skillCategories.map((skill) => (
                <option key={skill} value={skill}>
                  {skill === "All" ? "Filter by Skill: All" : `Includes: ${skill}`}
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Table & Cards Layout */}
      <div>
        {filteredVolunteers.length === 0 ? (
          <div id="no-volunteers-found" className="text-center py-16 px-4 bg-zinc-50 dark:bg-zinc-900 rounded-3xl border border-zinc-100 dark:border-zinc-800">
            <Smile className="w-12 h-12 text-zinc-300 dark:text-zinc-600 mx-auto mb-4" />
            <h4 className="font-display text-lg font-bold">No Volunteers Found</h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 max-w-sm mx-auto">
              No registered profiles match your search criteria. Try modifying your filters or searching another keyword.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            
            <div className="hidden lg:block overflow-hidden bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl shadow-xs">
              <table id="desktop-volunteers-table" className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-zinc-50 dark:bg-zinc-950 text-zinc-400 font-bold text-[10px] uppercase tracking-wider border-b border-zinc-100 dark:border-zinc-850">
                    <th className="py-4 px-6">Volunteer Info</th>
                    <th className="py-4 px-6">Location & Age</th>
                    <th className="py-4 px-6">Preferred Skills</th>
                    <th className="py-4 px-6">Availability</th>
                    <th className="py-4 px-6">Enrollment Date</th>
                    <th className="py-4 px-6 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/60 text-xs">
                  {filteredVolunteers.map((vol) => (
                    <tr key={vol.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-900/40 transition">
                      <td className="py-4 px-6">
                        <div>
                          <div className="font-bold text-zinc-900 dark:text-white">{vol.name}</div>
                          <div className="text-[11px] text-zinc-400 dark:text-zinc-400 mt-0.5">{vol.email}</div>
                          <div className="text-[10px] text-zinc-500 dark:text-zinc-550 font-medium font-mono">{vol.phone}</div>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="font-semibold text-zinc-800 dark:text-zinc-200">{vol.city}</div>
                        <div className="text-[10px] text-zinc-400 mt-0.5">{vol.age} yrs old</div>
                      </td>
                      <td className="py-4 px-6">
                        <p className="line-clamp-2 italic text-zinc-550 text-[11px]" title={vol.skills}>
                          {vol.skills}
                        </p>
                      </td>
                      <td className="py-4 px-6">
                        <span className="inline-block bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-450 px-2 py-0.5 rounded-full text-[10px] font-bold">
                          {vol.availability}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-[11px] text-zinc-400 dark:text-zinc-500 font-mono">
                        {formatDate(vol.createdAt)}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <button
                          onClick={() => {
                            if (window.confirm(`Are you sure you want to delete ${vol.name}'s volunteer registration record? This action is permanent.`)) {
                              onDeleteVolunteer(vol.id);
                            }
                          }}
                          className="p-2 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 rounded-xl transition text-zinc-400 cursor-pointer"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4.5 h-4.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards Layout */}
            <div id="mobile-volunteers-list" className="grid grid-cols-1 md:grid-cols-2 lg:hidden gap-4">
              {filteredVolunteers.map((vol) => (
                <div
                  key={vol.id}
                  className="p-5 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl shadow-xs space-y-4"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[10px] font-mono font-bold text-zinc-400 dark:text-zinc-500">{vol.id}</div>
                      <h4 className="font-display font-extrabold text-base text-zinc-900 dark:text-white mt-0.5">{vol.name}</h4>
                      <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium mt-0.5">{vol.email}</div>
                      <div className="text-xs text-zinc-400 font-mono">{vol.phone}</div>
                    </div>

                    <button
                      onClick={() => {
                        if (window.confirm(`Are you sure you want to delete ${vol.name}'s volunteer registration?`)) {
                          onDeleteVolunteer(vol.id);
                        }
                      }}
                      className="p-2 sm:p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 rounded-xl transition cursor-pointer"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs border-t border-zinc-100 dark:border-zinc-800 pt-3">
                    <div>
                      <span className="block text-[10px] text-zinc-400 uppercase tracking-widest">Location</span>
                      <span className="font-bold text-zinc-800 dark:text-zinc-200">{vol.city}</span>
                    </div>

                    <div>
                      <span className="block text-[10px] text-zinc-400 uppercase tracking-widest">Age</span>
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{vol.age} yrs</span>
                    </div>

                    <div className="col-span-2 pt-1">
                      <span className="block text-[10px] text-zinc-400 uppercase tracking-widest mb-1">Skills / Interests</span>
                      <p className="text-xs italic text-zinc-650 dark:text-zinc-350 line-clamp-3 bg-zinc-50 dark:bg-zinc-950 p-2.5 rounded-xl border border-zinc-100 dark:border-zinc-850">
                        {vol.skills}
                      </p>
                    </div>

                    <div className="col-span-2 flex items-center justify-between pt-2 border-t border-zinc-100 dark:border-zinc-800/80">
                      <span className="inline-block bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-450 px-3 py-1 rounded-full text-[10px] font-bold">
                        {vol.availability}
                      </span>
                      <span className="text-[10px] text-zinc-400 dark:text-zinc-550 font-mono">
                        Reg: {formatDate(vol.createdAt)}
                      </span>
                    </div>

                  </div>
                </div>
              ))}
            </div>

            <div className="text-center pt-4">
              <span className="text-xs text-zinc-400 font-medium">
                Showing {filteredVolunteers.length} of {totalCount} registered volunteers.
              </span>
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
