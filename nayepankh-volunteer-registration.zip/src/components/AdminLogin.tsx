import React, { useState } from "react";
import { ShieldAlert, KeyRound, User, Sparkles, Activity } from "lucide-react";

interface AdminLoginProps {
  onLoginSuccess: (token: string, user: { username: string }) => void;
}

export default function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Please fill in all credential fields.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        const data = await response.json();
        onLoginSuccess(data.token, data.user);
        setUsername("");
        setPassword("");
      } else {
        const data = await response.json();
        setError(data.error || "Access Denied. Check user credentials.");
      }
    } catch (err) {
      console.error(err);
      setError("Unable to connect to login API server. Make sure dev server is running.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="admin-login-card" className="w-full max-w-md mx-auto block bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xs animate-fade-in text-zinc-900 dark:text-zinc-100">
      
      {/* Icon header */}
      <div className="flex justify-center mb-5">
        <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/60 rounded-2xl text-amber-500">
          <ShieldAlert className="w-8 h-8" />
        </div>
      </div>

      <div className="text-center mb-6">
        <h3 className="font-display text-2xl font-extrabold text-zinc-900 dark:text-white">
          Admin Portal Access
        </h3>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1.5 font-medium">
          Secure sign-in for NayePankh Foundation Regional Coordinators and Administrators.
        </p>
      </div>

      {/* Demo Credentials Info Box  */}
      <div className="mb-6 p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-100/60 dark:border-emerald-905/40 text-emerald-800 dark:text-emerald-300 text-xs">
        <div className="flex items-center space-x-1.5 font-bold mb-1">
          <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
          <span>Demo Authentication Credentials:</span>
        </div>
        <p className="font-medium">Username: <span className="font-mono bg-emerald-100 dark:bg-emerald-950 px-1.5 py-0.5 rounded text-emerald-800 dark:text-emerald-400 font-bold">admin</span></p>
        <p className="font-medium mt-1">Password: <span className="font-mono bg-emerald-100 dark:bg-emerald-950 px-1.5 py-0.5 rounded text-emerald-800 dark:text-emerald-400 font-bold">nayepankh2026</span></p>
      </div>

      {error && (
        <div id="login-error-message" className="mb-4 p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-semibold border border-rose-100 dark:border-rose-950/40">
          {error}
        </div>
      )}

      <form id="admin-login-form" onSubmit={handleSubmit} className="space-y-4">
        
        {/* Username */}
        <div>
          <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
            Admin Handle / ID
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <User className="w-4 h-4" />
            </div>
            <input
              id="input-login-username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. admin"
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 dark:text-white text-sm"
              required
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
            Password Passcode
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <input
              id="input-login-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 dark:text-white text-sm"
              required
            />
          </div>
        </div>

        {/* Submit */}
        <button
          id="btn-login-submit"
          type="submit"
          disabled={loading}
          className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold shadow-xs transition-transform hover:-translate-y-0.5 active:translate-y-0 text-sm select-none"
        >
          {loading ? "Authenticating Admin..." : "Unlock Admin Dashboard"}
        </button>

      </form>
    </div>
  );
}
