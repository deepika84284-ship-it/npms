import React from "react";
import { Feather, Heart, Mail, Phone, ExternalLink, Globe } from "lucide-react";

export default function Footer() {
  return (
    <footer id="app-footer" className="mt-16 bg-white dark:bg-zinc-950 border-t border-zinc-100 dark:border-zinc-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          
          {/* Column 1: Organization brand info */}
          <div className="space-y-4 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start space-x-3">
              <div className="p-2 bg-emerald-50 dark:bg-emerald-950 rounded-xl border border-emerald-100 dark:border-emerald-900">
                <Feather className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <span className="font-display text-lg font-bold text-zinc-950 dark:text-white">NayePankh Foundation</span>
            </div>
            
            <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed font-normal">
              NayePankh Foundation is a government registered Non-Governmental Organization working extensively in uplifting underprivileged children, organizing food security campaigns, and supporting local communities across India.
            </p>
          </div>

          {/* Column 2: Quick resource links */}
          <div className="space-y-3 text-center md:text-left">
            <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Foundation Resources</h4>
            <ul className="text-xs space-y-2 font-medium text-zinc-650 dark:text-zinc-350">
              <li>
                <a 
                  href="https://nayepankh.org" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-emerald-600 dark:hover:text-emerald-405 flex items-center justify-center md:justify-start space-x-1"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>Official Website</span>
                  <ExternalLink className="w-3 h-3 text-zinc-400" />
                </a>
              </li>
              <li>
                <a 
                  href="https://nayepankh.org/about-us" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-emerald-600 dark:hover:text-emerald-405 flex items-center justify-center md:justify-start space-x-1"
                >
                  <span>Our Vision & Legacy</span>
                  <ExternalLink className="w-3 h-3 text-zinc-400" />
                </a>
              </li>
              <li className="text-zinc-400 dark:text-zinc-500 italic">
                National Youth Development Hubs
              </li>
            </ul>
          </div>

          {/* Column 3: Contact Info & Support */}
          <div className="space-y-3 text-center md:text-left">
            <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Connect Support</h4>
            <ul className="text-xs space-y-2 font-semibold">
              <li className="flex items-center justify-center md:justify-start space-x-2 text-zinc-650 dark:text-zinc-350">
                <Mail className="w-3.5 h-3.5 text-emerald-600" />
                <span>support@nayepankh.org</span>
              </li>
              <li className="flex items-center justify-center md:justify-start space-x-2 text-zinc-650 dark:text-zinc-350">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>+91 83185 18224</span>
              </li>
              <li className="text-[10px] text-zinc-400 font-normal leading-relaxed">
                Registered Office: Sector 4, Noida, Uttar Pradesh, India.
              </li>
            </ul>
          </div>

        </div>

        {/* Closing details and license */}
        <div className="mt-10 pt-8 border-t border-zinc-100 dark:border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[10px] text-zinc-400 text-center font-medium">
            &copy; {new Date().getFullYear()} NayePankh Foundation. All Rights Reserved. 
            <span className="block sm:inline sm:ml-2 text-emerald-600/65 font-bold">Technical Internship Capstone Project submission</span>
          </p>

          <p className="text-[10px] text-zinc-400 flex items-center justify-center space-x-1">
            <span>Built with devotion and</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            <span>for human empowerments</span>
          </p>
        </div>

      </div>
    </footer>
  );
}
