import React, { useState, useEffect } from "react";
import { Sparkles, HelpingHand, ShieldCheck, Heart, UserPlus, Info, Terminal, Award } from "lucide-react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import RegistrationForm from "./components/RegistrationForm";
import RegistrationSuccess from "./components/RegistrationSuccess";
import AdminLogin from "./components/AdminLogin";
import Dashboard from "./components/Dashboard";
import Footer from "./components/Footer";
import { Volunteer, AdminSession } from "./types";

export default function App() {
  const [currentTab, setCurrentTab] = useState("home");
  const [darkMode, setDarkMode] = useState(false);
  const [volunteers, setVolunteers] = useState<Volunteer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [lastRegistered, setLastRegistered] = useState<Volunteer | null>(null);

  // Sync Admin Session status with local storage to avoid logging out on reload
  const [adminSession, setAdminSession] = useState<AdminSession>(() => {
    try {
      const saved = localStorage.getItem("nayepankh_admin_session");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Error reading session from local storage", e);
    }
    return { token: null, user: null };
  });

  // Load volunteers on app mount
  const fetchVolunteers = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/volunteers");
      if (response.ok) {
        const data = await response.json();
        setVolunteers(data);
      } else {
        console.error("Failed to fetch volunteers");
      }
    } catch (err) {
      console.error("API Fetch Error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVolunteers();
  }, []);

  // Sync dark class on mount based on system pref or local storage
  useEffect(() => {
    const isDark = document.documentElement.classList.contains("dark") || 
                   localStorage.getItem("theme") === "dark" ||
                   window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (isDark) {
      document.documentElement.classList.add("dark");
      setDarkMode(true);
    }
  }, []);

  // Update theme setting in dark mode
  const handleDarkModeToggle = (dark: boolean) => {
    setDarkMode(dark);
    if (dark) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  };

  // Manage registration success callback
  const handleRegistrationSuccess = (newVolunteer: Volunteer) => {
    setLastRegistered(newVolunteer);
    // Refresh volunteer list state in database
    setVolunteers((prev) => [newVolunteer, ...prev]);
  };

  // Manage delete callback
  const handleDeleteVolunteer = async (id: string) => {
    try {
      const response = await fetch(`/api/volunteers/${id}`, {
        method: "DELETE",
      });
      if (response.ok) {
        setVolunteers((prev) => prev.filter((v) => v.id !== id));
      } else {
        alert("Could not delete record from server database.");
      }
    } catch (err) {
      console.error(err);
      alert("Network error: Could not complete deletion.");
    }
  };

  // Admin session handling
  const handleAdminLogin = (token: string, user: { username: string }) => {
    const session = { token, user };
    setAdminSession(session);
    localStorage.setItem("nayepankh_admin_session", JSON.stringify(session));
  };

  const handleAdminLogout = () => {
    const closedSession = { token: null, user: null };
    setAdminSession(closedSession);
    localStorage.removeItem("nayepankh_admin_session");
  };

  return (
    <div id="app-root-viewport" className="min-h-screen flex flex-col font-sans bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 transition-colors duration-300">
      
      {/* Top sticky brand header and theme selector */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        darkMode={darkMode}
        setDarkMode={handleDarkModeToggle}
        isAdmin={!!adminSession.token}
        onLogout={handleAdminLogout}
      />

      {/* Main viewport Container with fade-in animation */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-fade-in">
        
        {currentTab === "home" && (
          <div className="space-y-16">
            <Hero 
              onRegisterClick={() => setCurrentTab("register")} 
              volunteerCount={volunteers.length} 
            />
            
            {/* Mission Statement Visual Banner */}
            <section id="mission-highlight-section" className="p-8 sm:p-12 rounded-3xl bg-linear-to-r from-emerald-600 to-teal-500 text-white relative overflow-hidden shadow-md">
              <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 opacity-10 pointer-events-none">
                <HelpingHand className="w-96 h-96" />
              </div>
              <div className="relative z-10 max-w-2xl">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full text-white/95 inline-block mb-4">
                  OUR MISSION & CORE IDENTITY
                </span>
                <h3 className="font-display text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight mb-4">
                  Providing modern wings to enable vulnerable youth to fly autonomously.
                </h3>
                <p className="text-sm sm:text-base text-zinc-100/90 leading-relaxed font-normal mb-6">
                  NayePankh Foundation targets the grassroot problems by introducing technical education drives, career options guidance, basic life hygiene skills and food relief distribution directly within marginalized slums and communities.
                </p>
                <button
                  id="btn-register-scroller"
                  onClick={() => setCurrentTab("register")}
                  className="px-6 py-3 bg-white text-emerald-800 hover:bg-emerald-50 rounded-xl font-bold transition text-xs shadow-xs"
                >
                  Apply to Register Now
                </button>
              </div>
            </section>
          </div>
        )}

        {currentTab === "register" && (
          <div className="space-y-6">
            {lastRegistered ? (
              <RegistrationSuccess
                volunteer={lastRegistered}
                onReset={() => setLastRegistered(null)}
                onViewDashboard={() => {
                  setLastRegistered(null);
                  setCurrentTab("dashboard");
                }}
              />
            ) : (
              <RegistrationForm onSubmitSuccess={handleRegistrationSuccess} />
            )}
          </div>
        )}

        {currentTab === "dashboard" && (
          <div className="space-y-6">
            {adminSession.token ? (
              <Dashboard
                volunteers={volunteers}
                onDeleteVolunteer={handleDeleteVolunteer}
                onRefresh={fetchVolunteers}
                isLoading={isLoading}
              />
            ) : (
              <div className="max-w-xl mx-auto space-y-6">
                {/* Visual guidance header to show why login is required */}
                <div className="text-center p-6 bg-zinc-100/50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl">
                  <ShieldCheck className="w-10 h-10 text-emerald-600 dark:text-emerald-400 mx-auto mb-3" />
                  <h3 className="font-display text-lg font-bold">Authorized Personnel Only</h3>
                  <p className="text-xs text-zinc-550 dark:text-zinc-400 mt-1 max-w-sm mx-auto">
                    To access the registry database containing phone numbers, emails, and address locations of volunteers, please verify administrative credentials below.
                  </p>
                </div>
                <AdminLogin onLoginSuccess={handleAdminLogin} />
              </div>
            )}
          </div>
        )}

      </main>

      {/* Footer Branding section */}
      <Footer />

    </div>
  );
}
