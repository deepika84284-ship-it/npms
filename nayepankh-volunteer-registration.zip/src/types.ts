/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Volunteer {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  age: number;
  skills: string;
  availability: string;
  createdAt: string;
}

export interface AdminUser {
  username: string;
}

export interface AdminSession {
  token: string | null;
  user: AdminUser | null;
}
