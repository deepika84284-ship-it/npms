import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), "volunteers.json");

interface Volunteer {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  age: number;
  skills: string;
  availability: string;
  createdAt: string;
}

// Seed standard volunteer records if the file doesn't exist yet
function getVolunteers(): Volunteer[] {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      const initialVolunteers: Volunteer[] = [
        {
          id: "vol_1",
          name: "Rahul Sharma",
          email: "rahul.sharma@nayepankh.org",
          phone: "+91 98765 43210",
          city: "Delhi",
          age: 21,
          skills: "Teaching, Social Media coordination, Community outreach",
          availability: "Weekends",
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "vol_2",
          name: "Priya Patel",
          email: "priya.patel@example.com",
          phone: "+91 87654 32109",
          city: "Mumbai",
          age: 23,
          skills: "Event Management, Fundraising Campaigns",
          availability: "Flexible",
          createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "vol_3",
          name: "Amit Kumar",
          email: "amit.kumar@example.com",
          phone: "+91 76543 21098",
          city: "Bangalore",
          age: 20,
          skills: "Content Writing, Graphic Design & Media",
          availability: "Weekdays (Evenings)",
          createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        }
      ];
      fs.writeFileSync(DATA_FILE, JSON.stringify(initialVolunteers, null, 2), "utf8");
      return initialVolunteers;
    }
    const data = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading/writing database file:", err);
    return [];
  }
}

function saveVolunteers(volunteers: Volunteer[]) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(volunteers, null, 2), "utf8");
  } catch (err) {
    console.error("Error saving database file:", err);
  }
}

app.use(express.json());

// API Endpoints
app.get("/api/volunteers", (req, res) => {
  const volunteers = getVolunteers();
  res.json(volunteers);
});

app.post("/api/volunteers", (req, res) => {
  const { name, email, phone, city, age, skills, availability } = req.body;

  if (!name || !email || !phone || !city || !age || !skills || !availability) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const volunteers = getVolunteers();
  const newVolunteer: Volunteer = {
    id: "vol_" + Date.now().toString(36),
    name: String(name).trim(),
    email: String(email).trim().toLowerCase(),
    phone: String(phone).trim(),
    city: String(city).trim(),
    age: Number(age),
    skills: String(skills).trim(),
    availability: String(availability).trim(),
    createdAt: new Date().toISOString()
  };

  volunteers.unshift(newVolunteer);
  saveVolunteers(volunteers);
  res.status(201).json(newVolunteer);
});

app.delete("/api/volunteers/:id", (req, res) => {
  const { id } = req.params;
  let volunteers = getVolunteers();
  const initialLength = volunteers.length;
  volunteers = volunteers.filter((v) => v.id !== id);

  if (volunteers.length === initialLength) {
    return res.status(404).json({ error: "Volunteer not found" });
  }

  saveVolunteers(volunteers);
  res.json({ success: true, message: "Volunteer record deleted" });
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "nayepankh2026") {
    return res.json({ success: true, token: "admin-jwt-token-stub", user: { username: "admin" } });
  }
  return res.status(401).json({ error: "Invalid administrative credentials." });
});

async function main() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}

main().catch((err) => {
  console.error("Failed to start server", err);
  process.exit(1);
});
