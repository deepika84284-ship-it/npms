# NayePankh Foundation - Volunteer Registration & Administration System

A professional, full-stack, responsive, and modern Volunteer Registration and Management System designed for the **NayePankh Foundation** NGO. This application is suitable as a Technical Internship Capstone project submission, featuring rich visual branding, clean code practices, responsive validation, dark mode toggles, and administrative dashboards with persistent API endpoints.

---

## 🌟 Core Features

### 1. **Visual Introduction Home Page**
* **NayePankh branding**: Visually paired typography (using *Outfit* for headers, *Inter* for copy, and *JetBrains Mono* for system states) inspired by the name "New Wings", featuring emerald/teal and amber accents.
* **NGO Mission Cards**: Detailed insights into the foundation's charity pillars (Education, Food Security, Young Minds Uplift).
* **Live Community Sync Indicators**: Real-time stats counting active volunteers, lives impacted, and cities covered.
* **Actionable CTAs**: Seamless transitions motivating users to register.

### 2. **Interactive Registration Form**
* **Comprehensive Registration Fields**: Full Name, Email, Phone Number, City, Age, Skills/Interests, and Weekly Availability.
* **Proactive Client-side Validation**: Instant feedback highlighting errors (such as email formatting, name length requirements, minimum participant age, and complete inputs).
* **Interactive Suggestions**: Quick selectors representing commonly desired NGO skills (e.g., teaching, graphic design, fundraising) for quick input filling.
* **Confetti & Profile Confirmation**: Beautiful confirmation summary card displaying their assigned registered ID.

### 3. **Volunteer Dashboard & Administration Panel**
* **Role-based Authentication**: Secured with standard credentials to prevent unauthorized access to volunteer personal records (phone, location, and skills).
* **Search Engine**: Instantly search volunteers’ profiles in real-time by Name, Email, or Phone.
* **Advanced Category Filters**: Filter the live registry by City or specialized Skills on demand.
* **Administrative Deletions**: Permanently retire volunteer records from storage with modal verification boxes.
* **Instant CSV Directory Export**: Export active directories directly into standard Excel-compatible `.csv` documents with one click!

### 4. **Optional Full Stack Integrations**
* **Node.js and Express.js Backend**: Fully functioning REST API proxy hosted in the main server container.
* **Persistent Data Storage**: File-based backend database (`volunteers.json`) supporting GET list requests, POST additions, and DELETE actions.
* **Responsive Velvet Dark Mode**: Clean custom stylesheet toggling amber icons and slate-gray styles immediately.

---

## 🔒 Administrative Portal Credentials

To access the secured **Admin Panel** to search, filter, and delete registered volunteer logs:

* **Username**: `admin`
* **Password**: `nayepankh2026`

---

## 🛠️ Technical Stack

* **Frontend Framework**: React.js (v19)
* **Design Styling**: Tailwind CSS (v4)
* **Language System**: TypeScript (v5)
* **Backend Web Server**: Node.js & Express.js
* **Bundler & Dev Ecosystem**: Vite (v6) with dynamic `esbuild` configurations
* **Icon Engine**: Lucide React

---

## 📁 Modular Codebase Structure

* `server.ts` - Hosts the full REST API backend and handles Vite middleware bindings for assets.
* `volunteers.json` - Safe, persistent database repository containing seeded mock data.
* `src/App.tsx` - App router linking states, tabs, authentication, and layout sections.
* `src/types.ts` - Consistent TypeScript interfaces for data validation.
* `src/components/` - Highly cohesive split components:
  * `Navbar.tsx` - Title branding, mobile drawer, and Sign Out buttons.
  * `Hero.tsx` - NGO statistics, welcome copies, and main CTAs.
  * `RegistrationForm.tsx` - Complete form utilizing state hook validations.
  * `RegistrationSuccess.tsx` - Custom profile summary panel.
  * `AdminLogin.tsx` - Form verifying login handles.
  * `Dashboard.tsx` - Table metrics, filters, deletion prompts, and CSV export.
  * `ThemeToggle.tsx` - Dark-mode switcher.
  * `Footer.tsx` - Info cards detailing registered office location and internship submission credits.

---

## 📝 Compliance & Submission

Prepared with clean code, developer comments, responsive grids, and full error handlers to serve as a stellar Capstone Technical submission for the **NayePankh Foundation**.
